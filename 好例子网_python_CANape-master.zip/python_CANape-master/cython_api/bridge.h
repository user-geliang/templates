#ifdef __cplusplus
extern "C" {
#endif
#include "CANapAPI.h"
#ifdef __cplusplus
}
#endif
